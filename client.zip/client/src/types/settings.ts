export interface UserSettings {
    autoApproveGames: boolean;
    autoApproveFriends: boolean;
    notifications: boolean;
  }
  