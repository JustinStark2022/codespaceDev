export interface Alert {
    id: string;
    type: string;
    content: string;
    read: boolean;
    handled: boolean;
    createdAt: string;
  }
  