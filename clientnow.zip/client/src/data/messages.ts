import { ChatMessage } from "@/types/chat";

export const initialMessages: ChatMessage[] = [
  {
    sender: "bot",
    text: "Welcome to the Parent Dashboard! How can I assist you today?",
  },
];
