export interface ScriptureProgress {
    id: string;
    scriptureReference: string;
    content: string;
    memorized: boolean;
  }