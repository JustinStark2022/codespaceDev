// Test setup file for backend
process.env.NODE_ENV = 'test'
